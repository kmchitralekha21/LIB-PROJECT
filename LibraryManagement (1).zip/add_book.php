<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];

    $sql = "INSERT INTO books (title, author) VALUES ('$title', '$author')";
    if ($conn->query($sql) === TRUE) {
        echo "New book added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST">
    <h2>Add Book</h2>
    <label>Title:</label><br>
    <input type="text" name="title" required><br><br>
    <label>Author:</label><br>
    <input type="text" name="author" required><br><br>
    <button type="submit">Add Book</button>
</form>
