CREATE DATABASE library;

USE library;

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    is_issued BOOLEAN DEFAULT FALSE
);

CREATE TABLE issued_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    issued_to VARCHAR(255),
    issue_date DATE,
    FOREIGN KEY (book_id) REFERENCES books(id)
);
